//
//  mainViewController.swift
//  tabSync
//
//  Created by MacBook on 02/12/2015.
//  Copyright © 2015 Ameer Abllah. All rights reserved.
//

import UIKit
import Parse
import ParseUI
class mainViewController: UIViewController {
    
   
    @IBOutlet weak var usernameField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    @IBOutlet weak var emailField: UITextField!
    
    
    var actInd: UIActivityIndicatorView = UIActivityIndicatorView (frame: CGRectMake(0, 0, 150, 150)) as UIActivityIndicatorView
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationController!.navigationBar.barTintColor = UIColor(red: 255.0 / 255.0, green: 255.0 / 255.0, blue: 255.0/255.0, alpha: 1.0)
//        
//        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: "dismissKeyboard")
//        view.addGestureRecognizer(tap)
        
        self.actInd.center = self.view.center
        self.actInd.hidesWhenStopped = true
        self.actInd.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.Gray
        view.addSubview(self.actInd)
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func getSync(sender: AnyObject) {
        
        //TODO: if the UITextFields are blank. prompt an error alert
        
    }

    @IBAction func loginAction(sender: AnyObject) {
        
        let username = self.usernameField.text
        let password = self.passwordField.text
        let email = self.emailField.text
        
        
        self.actInd.startAnimating()
        
        
        let newUser = PFUser()
        newUser.username = username
        newUser.password = password
        newUser.email = email
        
        //save username in Message Database
        let newMessageObject:PFObject = PFObject(className: "Message")
        newMessageObject["username"] = self.usernameField.text
        newMessageObject.saveInBackgroundWithBlock { (success:Bool, error: NSError?) -> Void in
        }
        
        newUser.signUpInBackgroundWithBlock({ (succeed, error) -> Void in
       
            self.actInd.stopAnimating()
            
            if ((error) != nil) {
                
                let alert = UIAlertView (title: "Error", message: "\(error)", delegate: self, cancelButtonTitle: "OK")
                alert.show()
            } else {  // TODO: once the user click OK, UITextField will go blank
                let alert = UIAlertView(title: "Succeed! Welcome to SyncAlarm. Hit Get Sync to get started!", message: "Signed up", delegate: self, cancelButtonTitle: "OK")
                alert.show()
                
                let installation: PFInstallation = PFInstallation.currentInstallation()
                installation.addUniqueObject("Reload", forKey: "channels")
                installation["user"] = PFUser.currentUser()
                installation.saveInBackgroundWithBlock({ (success: Bool, error: NSError?) -> Void in
                })
                
            }
            
        })
        
    }

//    func dissmissKeyboard() {
//        
//        view.endEditing(true)
//    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        view.endEditing(true)
        super.touchesBegan(touches, withEvent: event)
    }


}
