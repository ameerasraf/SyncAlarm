//
//  editAlarmViewController.swift
//  tabSync
//
//  Created by Ameer Abllah on 26/11/2015.
//  Copyright © 2015 Ameer Abllah. All rights reserved.
//

import UIKit
import Parse
import ParseUI

class editAlarmViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var datePicker: UIDatePicker!
    @IBOutlet weak var alarmTitle: UITextField!
    @IBOutlet weak var alarmLabel: UILabel!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationController!.navigationBar.barTintColor = UIColor(red: 255.0 / 255.0, green: 255.0 / 255.0, blue: 255.0/255.0, alpha: 1.0)
        
        self.alarmTitle.delegate = self
        
        //self.displayAlarm(datePicker)
        //self.alarmLabel(datePicker)
//        NSTimer.scheduledTimerWithTimeInterval(0.1, target:self, selector: ("displayAlarm"), userInfo:nil, repeats: true)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func alarmLabel(sender: UIDatePicker) {
        
//        datePicker.text = NSDateFormatter.localizedStringFromDate(datePicker.date, dateStyle: NSDateFormatterStyle.MediumStyle, timeStyle: NSDateFormatterStyle.ShortStyle)
        
    }
    
    @IBAction func confirmAlarm(sender: AnyObject) {

        alarmLabel.text = NSDateFormatter.localizedStringFromDate(datePicker.date, dateStyle: NSDateFormatterStyle.MediumStyle, timeStyle: NSDateFormatterStyle.ShortStyle)
        
    }
    
    @IBAction func addTitle(sender: AnyObject) { //TODO: MAKE SURE USER PRESS CONFIRM ALARM FIRST BEFORE PROCEEDING
        print("The button was clicked.")
        
        let alarmObject: PFObject = PFObject (className: "EditAlarm")
        alarmObject["alarmSet"] = self.alarmLabel.text
        alarmObject["alarmTitle"] = self.alarmTitle.text
        alarmObject.saveInBackgroundWithBlock { (success:Bool, error: NSError?) -> Void in
    
            if (self.alarmLabel.text == "Label") {
                let alert = UIAlertView(title: "Error", message: "Please click confirm Alarm!", delegate: self, cancelButtonTitle: "OK")
            }
            
            if (success == true){
                let alert = UIAlertView(title: "Succeed", message: "Alarm Set!", delegate: self, cancelButtonTitle: "Continue")
                alert.show()
                NSLog("Success")
            } else {
                NSLog(error!.description)
            }
            dispatch_async(dispatch_get_main_queue()){
                self.alarmTitle.enabled = true
                self.alarmTitle.text = " "
                self.alarmLabel.enabled = true
                self.alarmLabel.text = " "
            }
            
            self.alarmTitle.endEditing(true)
            self.alarmLabel.endEditing(true)
       }
}
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        view.endEditing(true)
        super.touchesBegan(touches, withEvent: event)
    }

    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
