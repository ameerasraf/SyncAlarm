//
//  exitGroupViewController.swift
//  tabSync
//
//  Created by Ameer Abllah on 26/11/2015.
//  Copyright © 2015 Ameer Abllah. All rights reserved.
//

import UIKit

class exitGroupViewController: UIViewController { //TODO: it is not connected to navigation controller. so cannot Back Back and Back

    @IBOutlet weak var label: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationController!.navigationBar.barTintColor = UIColor(red: 255.0 / 255.0, green: 255.0 / 255.0, blue: 255.0/255.0, alpha: 1.0)

        NSTimer.scheduledTimerWithTimeInterval(0.1, target:self, selector: ("updateTime"), userInfo:nil, repeats: true)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func updateTime() {
        
        label.text = NSDateFormatter.localizedStringFromDate(NSDate(), dateStyle: NSDateFormatterStyle.FullStyle, timeStyle: NSDateFormatterStyle.MediumStyle)
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
