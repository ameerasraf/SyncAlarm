//
//  chatViewController.swift
//  tabSync
//
//  Created by Ameer Abllah on 12/11/2015.
//  Copyright © 2015 Ameer Abllah. All rights reserved.
//

import UIKit
import Parse
import ParseUI //TODO: multiple users can load the chat and user can leave chat room

class chatViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate {

    @IBOutlet weak var messageTableView: UITableView!
    @IBOutlet weak var messageTextField: UITextField!
    @IBOutlet weak var sendButton: UIButton!
    @IBOutlet weak var dockViewHeightConstraint: NSLayoutConstraint!
    var messagesArray: [String] = [String]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        NSNotificationCenter.defaultCenter().postNotificationName("reloadTimeline", object: nil)

        navigationController!.navigationBar.barTintColor = UIColor(red: 255.0 / 255.0, green: 255.0 / 255.0, blue: 255.0/255.0, alpha: 1.0)
        
        self.messageTableView.delegate = self
        self.messageTableView.dataSource = self
        self.messageTextField.delegate = self
        
        let tapGesture: UIGestureRecognizer = UIGestureRecognizer(target: self, action: "tableViewTapped")
        self.messageTableView.addGestureRecognizer(tapGesture)
        
        self.retrieveMessages()
        
    }

    
    func textFieldDidBeginEditing(textField: UITextField) {
        self.view.layoutIfNeeded()
        
        UIView.animateWithDuration(0.5, animations: {
            self.dockViewHeightConstraint.constant = 300
            self.view.layoutIfNeeded()
            
        }, completion: nil  )
    }
    
    func textFieldDidEndEditing(textField: UITextField) {
        self.view.layoutIfNeeded()
        UIView.animateWithDuration(0.5, animations: {
            
            self.dockViewHeightConstraint.constant = 75
            self.view.layoutIfNeeded()
            
            }, completion: nil  )
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func sendButtonTab(sender: UIButton) {
        
        self.messageTextField.endEditing(true)
        self.messageTextField.enabled = false
        self.sendButton.enabled = false
        
        let push:PFPush = PFPush()
        push.setChannel("Reload")
        let data: NSDictionary = ["alert":"", "badge":"0","content-available":"1", "sound":""]
        push.setData(data as [NSObject : AnyObject])
        push.sendPushInBackground()
        
        let newMessageObject:PFObject = PFObject(className: "Message")
        newMessageObject["Text"] = self.messageTextField.text
        newMessageObject.saveInBackgroundWithBlock { (success:Bool, error: NSError?) -> Void in
        
            if (success == true){
                self.retrieveMessages()
                NSLog("Success")
                
            } else {
            
                NSLog(error!.description)
            }
            
            //enable text field and send button
            dispatch_async(dispatch_get_main_queue()) {
            self.sendButton.enabled = true
            self.messageTextField.enabled = true
            self.messageTextField.text = ""
            }}}
    
    func tableViewTapped() {
        
        //force text field to end editing
        self.messageTextField.endEditing(true)
    }

    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
    
        let cell = self.messageTableView.dequeueReusableCellWithIdentifier("messageCell") as UITableViewCell?
        cell!.textLabel?.text = self.messagesArray[indexPath.row]
        
        return cell!
        
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return messagesArray.count
        }

    func retrieveMessages() {
        
        
        let query: PFQuery = PFQuery(className: "Message")
       // query.whereKey(key: String, containedIn: [AnyObject])
        query.findObjectsInBackgroundWithBlock { (objects: [PFObject]?, error: NSError?) -> Void in
            //clear the message array
            self.messagesArray = [String]()
            //loop trough the object array
            for messageObject in objects! {
                let messageText:String? = (messageObject as PFObject) ["Text"] as? String
                //Assign it into our messageArray
                if messageText != nil{
                    self.messagesArray.append(messageText!)
                }}
            //reload the table view
            dispatch_async(dispatch_get_main_queue()) {
            self.messageTableView.reloadData()
            }}}
    
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */


