//
//  AppDelegate.swift
//  tabSync
//
//  Created by Ameer Abllah on 06/11/2015.
//  Copyright © 2015 Ameer Abllah. All rights reserved.
//

import UIKit
import Parse

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {
        Parse.setApplicationId("aEP4kfoDnQDeSjMP58gmXCgvhpWKU07s83uSWl7M",
            clientKey: "DHDgIxbb6twni3pohPoCmZ7sN6IMY8jrDZV4T3op")
        
        let notificationsTypes = UIUserNotificationSettings(forTypes: [.Alert, .Sound, .Badge], categories: nil)
        UIApplication.sharedApplication().registerUserNotificationSettings(notificationsTypes)
        
        if let launchOptions = launchOptions as? [String : AnyObject] {
            if let notificationDictionary = launchOptions[UIApplicationLaunchOptionsRemoteNotificationKey] as? [NSObject : AnyObject] {
                self.application(application, didReceiveRemoteNotification: notificationDictionary)
            }
        }
        
//       let pushQuery = PFInstallation.query()!
//       pushQuery.whereKey("user", equalTo: PFUser.currentUser()!)

//        let push = PFPush()
//        push.setQuery(pushQuery)
//        push.setMessage("New message from \(PFUser.currentUser()!.username!)")
//        push.sendPushInBackground()
        
//        let settings = UIUserNotificationSettings(forTypes: [.Alert, .Sound, .Badge], categories: nil)
//        UIApplication.sharedApplication().registerUserNotificationSettings(settings)
//        UIApplication.sharedApplication().registerForRemoteNotifications()
        
//        if let launchOptions = launchOptions as? [String : AnyObject] {
//            if let notificationDictionary = launchOptions[UIApplicationLaunchOptionsRemoteNotificationKey] as? [NSObject : AnyObject] {
//                self.application(application, didReceiveRemoteNotification: notificationDictionary)
//            }
//        }
        
        return true
    }
    
    func application(application: UIApplication, didRegisterUserNotificationSettings notificationSettings: UIUserNotificationSettings) {
        UIApplication.sharedApplication().registerForRemoteNotifications()
    }
    
    func application(application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: NSData) {
        let currentInstallation:PFInstallation = PFInstallation.currentInstallation()
        currentInstallation.setDeviceTokenFromData(deviceToken)
        currentInstallation.saveInBackgroundWithBlock({ (succeed: Bool, error: NSError?) -> Void in
    
        })
    }
    
    func application(application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: NSError) {
        print(error.localizedDescription)
    }

    func application(application: UIApplication, didReceiveRemoteNotification userInfo: [NSObject : AnyObject]) {
        
        PFPush.handlePush(userInfo)
        //NSNotificationCenter.defaultCenter().postNotificationName("reloadTimeline", object: nil)
        
//        let notification:NSDictionary = userInfo.objectForKey("aps") as! NSDictionary
//        
//        if (notification.objectForKey("content-available") != nil){
//            if ((notification.objectForKey("content-available")?.isEqualToNumber(1)) != nil) {
//                NSNotificationCenter.defaultCenter().postNotificationName("reloadTimeline", object: nil)
//            }
//        }else{
//             PFPush.handlePush(userInfo as [NSObject : AnyObject])
//        }
//       
    }
    
//    func application(application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: NSData) {
//        let installation = PFInstallation.currentInstallation()
//        installation["user"] = PFUser.currentUser()
//        installation.setDeviceTokenFromData(deviceToken)
//        installation.saveInBackground()
//    
//    }


    func applicationWillResignActive(application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
    }

    func applicationDidEnterBackground(application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }

    func applicationWillEnterForeground(application: UIApplication) {
        // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
    }

//    func applicationDidBecomeActive(application: UIApplication) {
//         clearBadges()
//    }

    func applicationWillTerminate(application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }

//    func application(application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: NSData) {
//        let installation = PFInstallation.currentInstallation()
//        //installation["username"] = PFUser.currentUser()
//        installation.setDeviceTokenFromData(deviceToken)
//        installation.saveInBackground()
//        
//        let pushQuery = PFInstallation.query()!
//        pushQuery.whereKey("username", equalTo: "Ameer Asraf")
//        
//        let data = ["alert" : "New message from \(PFUser.currentUser()!.username!)", "badge" : "Increment"]
//        let push = PFPush()
//        push.setQuery(pushQuery)
//        push.setData(data)
//        push.sendPushInBackground()
//    }
    
//
//    func clearBadges() {
//        let installation = PFInstallation.currentInstallation()
//        installation.badge = 0
//        installation.saveInBackgroundWithBlock { (success, error) -> Void in
//            if success {
//                print("cleared badges")
//                UIApplication.sharedApplication().applicationIconBadgeNumber = 0
//            }
//            else {
//                print("failed to clear badges")
//            }
//        }
//    }

}

