//
//  ViewController.swift
//  tabSync
//
//  Created by Ameer Abllah on 06/11/2015.
//  Copyright © 2015 Ameer Abllah. All rights reserved.
//

import UIKit //TODO: PARSE NOTIFICATION! once the user click on 'nextButton', Parse will take the 'title' and send push notifications to all participant.
import Parse
import ParseUI

class ViewController: UIViewController,UITableViewDataSource, UITableViewDelegate {
    

    @IBOutlet weak var nameTableView: UITableView!
    @IBAction func nextButton(sender: AnyObject) {
    }
    var names: [String] = [String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationController!.navigationBar.barTintColor = UIColor(red: 255.0 / 255.0, green: 255.0 / 255.0, blue: 255.0/255.0, alpha: 1.0)
        
        self.nameTableView.delegate = self
        self.nameTableView.dataSource = self
        self.retrieveName()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
    
        let cell = self.nameTableView.dequeueReusableCellWithIdentifier("nameCell") as UITableViewCell?
   
        cell!.textLabel?.text = self.names[indexPath.row]
        //let user:PFUser = (self.names[indexPath.row] as? PFUser)!
        
        return cell!
        
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        let messageAlert: UIAlertController = UIAlertController(title: "NOTIFY YOUR FRIENDS!", message: "Make your own customs notifications!", preferredStyle: UIAlertControllerStyle.Alert)
        
        messageAlert.addTextFieldWithConfigurationHandler { (textfield: UITextField) -> Void in
            textfield.placeholder = "Your notifications..."
        }
        
        messageAlert.addAction(UIAlertAction(title: "Send", style: UIAlertActionStyle.Default, handler: {
            (alertAction:UIAlertAction) -> Void in
            //send to parse here
            
            let pushQuery = PFInstallation.query()!
            pushQuery.whereKey("user", equalTo: PFUser.currentUser()!)

//            let pushQuery:PFQuery = PFInstallation.query()!
//            pushQuery.whereKey("user", equalTo: self.names[indexPath.row]) //names should be in array
            
            let push:PFPush = PFPush()
            push.setQuery(pushQuery)
            
            //get content of the textfields
            let textfield: NSArray = messageAlert.textFields! as NSArray
            let messageTextField: UITextField = textfield.objectAtIndex(0) as! UITextField
            
            push.setMessage(messageTextField.text)
            push.sendPushInBackground()
        }))
        
        messageAlert.addAction(UIAlertAction(title: "Cancel", style: UIAlertActionStyle.Default, handler: nil))
        self.presentViewController(messageAlert, animated: true, completion: nil)
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return names.count
    }
    
//    //swipe to delete
//    func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
//    }
//    
//    
//    func tableView(tableView: UITableView, editActionsForRowAtIndexPath indexPath: NSIndexPath) -> [UITableViewRowAction]? {
//        //TODO: after user choose 'YES' make some changes at the cell eg cell turns other color etc
//        
//        let swipeAction = UITableViewRowAction(style: UITableViewRowActionStyle.Default, title: "Choose" , handler: { (action:UITableViewRowAction!, indexPath:NSIndexPath!) -> Void in
//            
//            let shareMenu = UIAlertController(title: nil, message: "You Sure?", preferredStyle: .ActionSheet)
//            let yesAction = UIAlertAction(title: "Yes", style: UIAlertActionStyle.Default, handler: nil)
//            let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.Cancel, handler: nil)
//            
//            shareMenu.addAction(yesAction)
//            shareMenu.addAction(cancelAction)
//
//            self.presentViewController(shareMenu, animated: true, completion: nil)
//        })
//        return [swipeAction]
//    }
    
    func retrieveName() {
        
        let query: PFQuery = PFQuery(className: "_User")
        query.findObjectsInBackgroundWithBlock { (objects: [PFObject]?, error: NSError?) -> Void in
            
            //clear the message array
            self.names = [String]()
            
            for nameObject in objects! {
                //Retrieve the text column value of each PFObject
                let nameText:String! = (nameObject as PFObject) ["username"] as? String
                //Assign it into messageArray
                if nameText != nil{
                    self.names.append(nameText!)
                }
            }
            //reload the view
            dispatch_async(dispatch_get_main_queue()) {
                self.nameTableView.reloadData() 
                    NSLog("OK")
            }}}
    
    }


