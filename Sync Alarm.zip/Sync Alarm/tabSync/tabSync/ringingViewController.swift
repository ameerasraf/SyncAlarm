//
//  ringingViewController.swift
//  tabSync
//
//  Created by MacBook on 06/12/2015.
//  Copyright © 2015 Ameer Abllah. All rights reserved.
//

import UIKit
import AVFoundation
import Parse
import ParseUI

class ringingViewController: UIViewController {
    @IBOutlet weak var timeTitle: UILabel!
    @IBOutlet weak var alarmTitle: UILabel!
    var audioPlayer: AVAudioPlayer!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationController!.navigationBar.barTintColor = UIColor(red: 255.0 / 255.0, green: 255.0 / 255.0, blue: 255.0/255.0, alpha: 1.0)
        NSTimer.scheduledTimerWithTimeInterval(0.1, target:self, selector: ("updateTime"), userInfo:nil, repeats: true)
        
        retrieveTitle()
        alarmRinging()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func alarmRinging(){
        
        super.viewDidLoad()
        let musicPath = NSBundle.mainBundle().pathForResource("alarm", ofType: "wav")
        let url = NSURL(fileURLWithPath: musicPath!)
        
        do{
            audioPlayer = try AVAudioPlayer(contentsOfURL: url)
        }catch _ {
            audioPlayer = nil
        }
        audioPlayer.numberOfLoops = -1
        audioPlayer.prepareToPlay()
        audioPlayer.play()
        
    }

    
    @IBAction func okButton(sender: AnyObject) {
        audioPlayer.stop()
        
    }
    
    func updateTime() {
        
        timeTitle.text = NSDateFormatter.localizedStringFromDate(NSDate(), dateStyle: NSDateFormatterStyle.MediumStyle, timeStyle: NSDateFormatterStyle.ShortStyle)
        
    }
    
    func retrieveTitle(){
        
        let query = PFQuery(className: "EditAlarm")
        query.findObjectsInBackgroundWithBlock { (namelist: [PFObject]?, error : NSError?) -> Void in
            
            for list in namelist! {
                let output:String? = (list as PFObject)["alarmTitle"] as? String
                if output != nil{
                self.alarmTitle.text = output
                }
            }}
    }

    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
