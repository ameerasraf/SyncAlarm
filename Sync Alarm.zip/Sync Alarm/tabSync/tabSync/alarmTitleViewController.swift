//
//  alarmTitleViewController.swift
//  tabSync
//
//  Created by Ameer Abllah on 26/11/2015.
//  Copyright © 2015 Ameer Abllah. All rights reserved.
//

import UIKit
import Parse
import ParseUI 

class alarmTitleViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet weak var tblAlarm: UITableView!
    @IBAction func addContact(sender: AnyObject) {
    }
    var titleArray: [String] = [String()]
    var timeArray: [String] = [String()]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationController!.navigationBar.barTintColor = UIColor(red: 255.0 / 255.0, green: 255.0 / 255.0, blue: 255.0/255.0, alpha: 1.0)
        
        self.tblAlarm.delegate = self
        self.tblAlarm.dataSource = self
        self.retrieveTitleName()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        
        if (editingStyle == UITableViewCellEditingStyle.Delete){
            titleArray.removeAtIndex(indexPath.row)
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: UITableViewRowAnimation.Automatic)
            print("delete this row")
            self.tblAlarm.reloadData()
            
        }
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return titleArray.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        var cell = self.tblAlarm.dequeueReusableCellWithIdentifier("titleCell") as UITableViewCell?
        if ( cell != nil) {
            
            cell = UITableViewCell(style: UITableViewCellStyle.Subtitle, reuseIdentifier: "titleCell")
        }
        
        cell!.textLabel!.text = self.timeArray[indexPath.row]
        cell!.detailTextLabel?.text = self.titleArray[indexPath.row]
        return cell!
    }
    
    func retrieveTitleName() {
        
        let query: PFQuery = PFQuery(className: "EditAlarm")
        query.findObjectsInBackgroundWithBlock { ( objects: [PFObject]?, error: NSError?) -> Void in
            self.titleArray = [String] ()
            self.timeArray = [String] ()
            
                for titleObject in objects! {
                    
                let titleText: String! = (titleObject as PFObject) ["alarmTitle"] as? String
                if titleText != nil  {
                    self.titleArray.append(titleText)
                }
            }
            
            for timeObject in objects! {
                
                let timeText: String! = (timeObject as PFObject) ["alarmSet"] as? String
                if timeText != nil {
                    self.timeArray.append(timeText)
                }
            }
            dispatch_async(dispatch_get_main_queue()) {
                self.tblAlarm.reloadData()
            }
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

