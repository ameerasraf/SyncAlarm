//
//  participantsViewController.swift
//  tabSync
//
//  Created by Ameer Abllah on 15/11/2015.
//  Copyright © 2015 Ameer Abllah. All rights reserved.
//

import UIKit
import Parse
import ParseUI

class participantsViewController: UIViewController,UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var nameTableView: UITableView!
    var names: [String] = [String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationController!.navigationBar.barTintColor = UIColor(red: 255.0 / 255.0, green: 255.0 / 255.0, blue: 255.0/255.0, alpha: 1.0)
        
        self.nameTableView.delegate = self
        self.nameTableView.dataSource = self
        retrieveName()

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
    
    let cell = self.nameTableView.dequeueReusableCellWithIdentifier("nameCell") as UITableViewCell?
    
    cell!.textLabel?.text = self.names[indexPath.row]
    return cell!
    
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return names.count
    }
    
    func retrieveName() {
        
        let query: PFQuery = PFQuery(className: "_User")
        query.findObjectsInBackgroundWithBlock { (objects: [PFObject]?, error: NSError?) -> Void in
            
            //clear the message array
            self.names = [String]()
            
            for nameObject in objects! {
                //Retrieve the text column value of each PFObject
                let nameText:String! = (nameObject as PFObject) ["username"] as? String
                //Assign it into messageArray
                if nameText != nil{
                    self.names.append(nameText!)
                }
            }
            //reload the view
            dispatch_async(dispatch_get_main_queue()) {
                self.nameTableView.reloadData()
                NSLog("OK")
            }}}

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

    
}
